import pstats
p=pstats.Stats("timing.txt")
p.sort_stats('cumulative').print_stats(30)
print
#p.sort_stats('time').print_stats(10)
p.sort_stats('time').print_callers(10)
