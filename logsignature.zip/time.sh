python2.6 -m cProfile -o timing.txt logsignature.py
